import React from "react";
const MovieListingHeading = (props) => {
  return (
    <div className="col">
      <h1>{props.heading}</h1>
    </div>
  );
};

export default MovieListingHeading;
